// YAHOO! Error Handler!

// Extending the basic version

if (YAHOO.ErrorHandler) {

/**
 * Sets the level of error reporting, whereas:
 * 0 or unset:  just beacon to server
 * 1: output to console
 * @method setType
 * @param {Int} type level or error reporting
 */
YAHOO.ErrorHandler.setType = function (type) {
    if (!type) { // just beacon
         this._Log = this.beaconError;
    } else if (type === 1) { // console
        if (typeof(console) != 'undefined'){
            this._Log = function (err) {
                console.log(this.formatter(err));
            };
        }
    }
    //else if (type === 2) { // YAHOO logger
    //     this._Log = YAHOO.log;
    //     this.myLogReader = new YAHOO.widget.LogReader("myLogger", this.loggerConfig);
    //}
};

//YAHOO.ErrorHandler.prototype.loggerConfig = {
//    width: "50em",
//    height: "30em",
//    footerEnabled: false,
//    draggable: true
//};

/**
 * Formats error object to display nicely in console
 * @method formatter
 * @param {Object} err error object
 * @return {String} nicely formatted string
 */
YAHOO.ErrorHandler.formatter = function (err) {
    var str = "";
    for (var i in err) {
         str += i + ": \t";
         if (i.length < 5) {
              str += "\t";
         }
         str += err[i] + "\n";
    }
    return str;
};

/**
 * Handler for custom errors
 * @method logRunTimeError
 * @param {Object} err error object
 */
YAHOO.ErrorHandler.logRunTimeError = function (err) {
    var parts = err.message.split(",");
    
    err.message = parts[0];   
    if (parts.length > 1) {
        err.section = parts[1];
    } 

    this._Log(this.addProps(err), "error");
};


/* ==== Helper Stuff ==== */

/**
 * Holds custom error messages
 */
YAHOO.ErrorHandler.ErrorMessages = {
    ElementNotFound: "This Element Does Not Exist",
    UnexpectedAjaxResponse: "Unexpected Ajax Response"
};

/**
 * Checks if XHR response matches expected type
 * @method isProperXHRResponse
 * @param {String} response plain text response from server
 * @param {String} expectedType the expected type of the response (e.g. "object", "html")
 * @return {Boolean} 
 */
YAHOO.ErrorHandler.isProperXHRResponse = function (response, expectedType) {
	// if response is empty
	if (response === "" ) {
		return false;	
	} else {
        response = response.replace(/^\s+|\s+$/g,""); // removing unnecessary whitespace from response
        
        var firstChar = response.charAt(0);
        var lastChar = response.charAt(response.length-1);
		
        // check if it matches the expected type
		if (expectedType === "object") {
			if (!(firstChar === "{" && lastChar === "}")) {
				return false;
			}
		} else if (expectedType === "html") {
			if (!(firstChar === "<" && lastChar === ">")) {
				return false;
			}
		} else if (typeof response !== expectedType) {
			return false;
		}
	}
	return true;
};

/**
 * Shortens a textstring (XHR response)
 * @method shortenXHRResponse
 * @param {String} response plain text response from server
 * @param {String} limit number of characters to be limited to
 * @return {String} shortened response 
 */
YAHOO.ErrorHandler.shortenXHRResponse = function (response, limit) {
	var stringLimit = limit || 200;
	if (response.length > stringLimit) { // shorten response in case it is too long (e.g. HTML 500 page)
		return response.slice(0, (stringLimit - 1)) + "...";   
	} else {
		return response;
	}
};
}
