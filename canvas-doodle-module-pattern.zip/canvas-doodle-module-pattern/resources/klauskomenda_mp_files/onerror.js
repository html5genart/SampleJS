// YAHOO! Error Handler!

// basic version of
// http://vault.yahoo.com/viewcvs/yahoo/js/common/onerror.js?rev=HEAD&content-type=text/vnd.viewcvs-markup

// Create YAHOO object, as we can't be sure this is run at the very start of the pageload
if (!this.YAHOO) {
     var YAHOO = {};
}

/**
 * YAHOO! Error Handler Singleton
 * Provides functionality to beacon standard JavaScript errors on the page
 * to a server
 * @author Klaus Komenda <komenda@yahoo-inc.com>
 * @namespace YAHOO
 * @class ErrorHandler
 */
YAHOO.ErrorHandler = {
     time: 0,
     
     /**
      * handles default script errors
      * @method onerror
      * @param {String} msg error message
      * @param {String} url url to file where error occurred
      * @param {String} line linenumber where error occurred
      */
     onerror:  function (msg, url, line) {
          var h = this,           // Shortcut to the Error Handler object
              t = new Date().valueOf(),   // now
              err; // error object
              
          // Has it been too soon, or are we ready to send another error?
          if (t >= h.time + (h.interval || 1e4)) {
               // Update the flooding rejection timer.
               h.time = t;
               
               err = {
                   fileName: url,
                   message: msg,
                   lineNumber: line
               };
               if (this._Log) {
                    this._Log(this.addProps(err));
               } else {
                    this.beaconError(this.addProps(err));
               }
          }
     },
     
     /**
      * beacons error to server
      * @method beaconError
      * @param {Object} err error object
      */
     beaconError: function (err) {
          var ver = "$Revision: 1.0 $", // CVS version number
                i; // image used for beaconing
                
          ver = ver.substring(11, ver.length-2); // extract pure version number
          errorMsg = this.toQuerystring(err); // format error object for beaconing
          
          i = new Image(); // Create a new image object. Set its SRC url.
          i.src = 'http://kkv5-dev.crush.com/wp-content/themes/back2black/images/e.gif?v=' + ver
               + errorMsg;
               
            if (typeof(console) != 'undefined'){
                console.log(i.src);
            }
          
          // We don't want the image to get garbage collected immediately, so we give it
          // 10 seconds before we clear our reference to it. That should give the
          // browser plenty enough time to get the request onto the wire. We don't care if
          // a response comes back.
          setTimeout(function () {
              i = null;
          }, 1e4);
     },
     
     /**
      * Adds additional info to error object
      * @method addProps
      * @param {Object} err error object
      * @return {Object} error object with additional info properties
      */
     addProps: function (err) {
          err.userAgent = navigator.userAgent;
          err.platform = navigator.platform;
          return err;
     },
     
     /**
      * Converts error object into URL query string
      * @method toQuerystring
      * @param {Object} err error object
      * @return {String} error message as URL query string 
      */
     toQuerystring: function (err) {
          var e = encodeURIComponent, str = "";
          for (var i in err) {
               str +=  "&" + e(i) + "=" + e(err[i]);
          }
          return str;
     }
};

var YEH = YAHOO.ErrorHandler;
window.onerror=function(msg, url, code) { YEH.onerror.apply(YEH, [msg, url, code]); return true; };