Private properties, using closures (#54)
----------------------------------------

    function Ninja(name){ 
      this.name = name;

      this.changeName = function(name){ 
        this.name = name; 
      }; 
 
      this.changeName = function(name) {
          this.name = name;
      };

      this.getName = function() {
         return this.name;
      };
    } 

    var ninja = new Ninja("john");
    ninja.name = "Billy";
    alert(ninja.getName());


    Q: How can we make 'name' private?
    A: Make it private with a var in a closure provided by the function.

    function Ninja(name){
      var privateName = name; // var: private

      this.getName = function() {
         return privateName;
      };

      this.changeName = function(newName) {
          privateName = newName;
      };
    } 

    var ninja = new Ninja("john");
    ninja.name = "Billy";
    alert(ninja.getName());


    * Still better (reuse the same variable 'name' in the function closure)

    function Ninja(name){   // name is still private to this function
      this.getName = function() {
         return name;
      };

      this.changeName = function(newName) {
          name = newName;
      };
    } 

    var ninja = new Ninja("john");
    ninja.changeName('Pizza');
    ninja.name = "Billy";
    alert(ninja.getName());



JS Module Pattern
-----------------

   * Private state using "var" within the top of the function (scope/closure)
   * Public API interface as part of the return
   * Self-invoking function
   
   var ShapeFactory = (function(options) {
   	// Private state within this closure
   	var defaultColor = "red";
   	
   	var myCreateCircle = function() {
   	};
   	
   	var myCreateRectangle = function() {
   	};
   	
   	return {
   		createCircle    : myCreateCircle,
   		createRectangle : myCreateRectangle
   	};
   })(); // Self-invoking function

   // Also known as the "Revealing Module Pattern"
   
   
   The convention is to use the same names for the module pattern
   
   var ShapeFactory = (function(options) {
   	// Private state within this closure
   	var defaultColor = "red";
   	
   	var createCircle = function() {
   	};
   	
   	var createRectangle = function() {
   	};
   	
   	return {
   		createCircle    : createCircle,		// using same name
   		createRectangle : createRectangle	// using same name
   	};
   })(); // Self-invoking function
   


   #60: The anonymous wrapper functions are also useful for wrapping libraries.

   (function(){ 
     var ShapeFactory = window.ShapeFactory = function(){ 
       // Initialize
     }; 

     // ... 
   })();



References
----------

JS Module Pattern
http://www.yuiblog.com/blog/2007/06/12/module-pattern/
http://www.klauskomenda.com/code/javascript-programming-patterns/
http://www.adequatelygood.com/2010/3/JavaScript-Module-Pattern-In-Depth

JS Design Patterns
http://addyosmani.com/resources/essentialjsdesignpatterns/book/

Closures
http://jibbering.com/faq/notes/closures/

   
